<footer class="main-footer">
    {{-- <div class="float-right d-none d-sm-block" style="padding-right: 65px">
        <a href="#" class="text-dark pr-4"><i class="nav-icon fas fa-circle"></i> About us</a>
        <a href="#" class="text-dark pr-2"><i class="nav-icon fas fa-circle"></i> Page</a>
    </div>
    2022 &copy; <a class="text-dark" href="#">CHUOICANHO | www.chuoicanho.com</a>. --}}
</footer>
