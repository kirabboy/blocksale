    </div>
</main>
<footer>
    <div class="container-fluid">
        <div class="footer-1">
            <div>
                <a href="#">
                    <img src="{{asset('public/image/logo.png')}}" alt="logo">
                </a>
            </div>
        </div>
        <div class="footer-2">
            <p>Copyright © LINHANH - 2022</p>
        </div>
    </div>
</footer>
